### John Alejandro Malagón
### 201713658
### Universidad de los Andes
### Taller de R - Task 2
## R versió 4.0.5 (2021-03-31)
## Running under: Windows 7 x64 (build 7601) Service Pack 1


getwd()
sessionInfo()

#Limpieza del entorno e instalación de paquetes 
rm(list = ls())
require("pacman")
require("rio")
require("tidyverse")
require("dplyr")
require("broom")
require("sf")
require("osmdata")
require("xm12")
require("rvest")
require("leaflet")
require("ggsn")
require("tmap")
require("stargazer")
require("margins")
require("mfx")
require("modelsummary")
require("XML")


# 1. Datos espaciales
##Para el desarrollo de este punto se escogio a Bogota debido a que se conoce la ciudad relativo a las demas ciudades

# Descarga de datos
# Estaciones de bus
osm = opq(bbox = getbb("Bogotá Colombia")) %>%
  add_osm_feature(key = "amenity", value = "bus_station") %>%
  osmdata_sf()


amenities = osm$osm_points %>% dplyr::select(osm_id,amenity)

# Vias principales y de transporte masivo
calles = opq(bbox = getbb("Bogota Colombia")) %>%
  add_osm_feature(key = "Autopista") %>%
  osmdata_sf()

street = street$osm_lines %>% dplyr::select(osm_id,name)

# Vías principales que sean de Transmilenio
calles = calles %>%
  subset(str_detect(name,"Transmilenio")==T)

# Limites de los barrios 

# Limites de los barrios
barrio = opq(bbox = getbb("Bogota Colombia")) %>%
  add_osm_feature(key = 'admin_level', value = '9') %>% 
  osmdata_sf()

barrio = barrio$osm_multipolygons %>% dplyr::select(osm_id,name,geometry)

# 1.2 Visualizacion de informacion 
# Visualizacion estaciones de bus
leaflet() %>% 
  addTiles() %>% 
  addCircleMarkers(data=amenities, weight=1 , col="green")

# Visualizacion de vias principales transmilenio
leaflet() %>%
  addTiles() %>%
  addPolylines(data=street,col="red")

# Visualizacion de limites de barrios o manzanas
tmap::qtm(barrio)


# 1.3 Estimacion de distancias

# Distancia promedio de barrio o manzana hasta estacion
distancia_bus = st_distance(x=barrio, y=amenities)
View(distancia_bs)

# Promedio por barrio de la distancia a cada estacion
mean_bus = apply(distancia_bus,1,mean)

# Guardar el promedio donde esta guarda la informacion de los barrios
barrio$means_bs = mean_bs





# Distancia promedio de barrio/manza hasta vías principales transmilenio
distancia_vias = st_distance(x=barrio, y=street)
View(distancia_vias)

  # Promedio por barrio de la distancia a cada via principal de Transmilenio
mean_vias = apply(distancia_vias,1,mean)

# Guardar el promedio donde esta guarda la informacion de los barrios
barrio$mean_vias = mean_vias



# Tablas con las estadísticas descriptivas de las variables de distancias
# Promedio de la distancia de las estaciones de bus
sum_bus = summary(barrio$means_bus)
sum_bus
# Tabla con las estadísticas descriptivas para 
# el promedio de la distancia a vías principales del Transmilenio
sum_vias = summary(barrio$mean_vias)
sum_vias

# 1.4 Plot Mapping
# Mapa cuartiles estacion de buses
quantiles_bus=quantile(barrio$means_bus, probs = seq(0, 1, 1/4))
quantiles_bus

# Categorizar los barrios por los cuartiles
barrio <- barrio %>%
  mutate(mean_bs_q = cut(mean_bs, breaks = quantiles_bus,
                         include.lowest = T, dig.lab=5))
# Graficas usando ggplot la informacion por cuartiles
plot_estaciones = ggplot() +
  geom_sf(data = barrio, aes(fill = mean_bs_q), color = "black", size = 0.25) + 
  scale_fill_brewer(name="Distancia promedio [m]", palette = "YlGn",
                    guide = guide_legend(override.aes = list(linetype = "blank", shape = NA)))

# Exportar el grafico a la carpeta output
ggsave(plot=plot_estaciones , filename="task 3/output/quartiles_estacion_buses.pdf" , width=6.5 , height=8)

# 1.4.2 Mapa cuartiles vias principales de Transmilenio
# Los cuartiles de la variable de promedio de distancia hasta via principal de Transmilenio
quantiles_vias=quantile(barrio$mean_via, probs = seq(0, 1, 1/4))
quantiles_vias

# Categorizar los barrios por los cuartiles
barrio <- barrio %>%
  mutate(mean_vias_q = cut(mean_via, breaks = quantiles_vias,
                           include.lowest = T, dig.lab=5))

# Graficas usando ggplot la informacion por cuartiles
plot_vias = ggplot() +
  geom_sf(data = barrio, aes(fill = mean_vias_q), color = "black", size = 0.25) + 
  scale_fill_brewer(name="Distancia promedio [m]", palette = "YlGnBu",
                    guide = guide_legend(override.aes = list(linetype = "blank", shape = NA)))

# Exportar el grafico a la carpeta output
ggsave(plot=plot_vias , filename="task 3/output/quartiles_vias.pdf" , width=6.5 , height=8)

# 1.5 Exportar datos (Class-04)
export(barrio,"task 3/output/barrios.rds") 


# 2. Regresiones (Class-13)
# 2.1 Importar
datos = import(file = "task 3/output/f_mapmuse.rds")

# Modelo de regresion con la variables de la base de datos
ols = lm(fallecido ~ 
           as.factor(tipo_accidente)+year+month+as.factor(condicion)
         +as.factor(genero) + as.factor(actividad) + as.factor(cod_mpio)
         +dist_hospi+dist_cpoblado+dist_vias
         ,datos)

# 2.2 Coefplot
# Graficar los coeficientes
modelplot(ols) + coord_flip()+labs(title="Gráfico con los coeficientes de las estimaciones")
db = tidy(ols , conf.int = TRUE)

# Exportar el grafico de los coeficientes
jpeg("task 3/output/coeficientes.jpeg")
ggplot(db , aes(x = estimate, y = term)) + theme_light() + 
  geom_vline(aes(xintercept = 0),color="red",linetype="dashed") + 
  geom_errorbar(width=.5, aes(xmin=conf.low, xmax=conf.high) , col="black" , show.legend = T) + 
  geom_point(size = 3,show.legend = F , col="black") +
  theme(axis.text = element_text(color = "black", size = 10))
dev.off()

# 2.3 Estimacion
# 2.3.1 Logit
# Modelo logit
logit = glm(fallecido ~ 
              as.factor(tipo_accidente)+year+month+as.factor(condicion)
            +as.factor(genero) + as.factor(actividad) + as.factor(cod_mpio)
            +dist_hospi+dist_cpoblado+dist_vias
            ,datos, family = binomial(link="logit"))
# 2.3.2 Probit
# Modelo probit
probit = glm(fallecido ~ 
               as.factor(tipo_accidente)+year+month+as.factor(condicion)
             +as.factor(genero) + as.factor(actividad) + as.factor(cod_mpio)
             +dist_hospi+dist_cpoblado+dist_vias
             ,datos,family = binomial(link = "probit"))

# 2.4 Exportar resultados
# Exportar los resultados en un archivo .txt en forma de tabla
stargazer(ols, logit, probit,
          type= 'text',
          dep.var.labels = c('','Fallecido',''), 
          df = FALSE,
          digits = 3, 
          out = paste0('task 3/output/modelos.text'))

# 2.5 Presentar resultados
# Efecto marginal promedio de la distancia hasta un hospital del modelo logit
logit_marg = margins(logit, variables = ("dist_hospi"))

# Efecto marginal promedio de la distancia hasta un hospital del modelo probit
probit_marg = margins(probit, variables = ("dist_hospi"))

# Exportar el grafico efecto marginal promedio de la distancia hasta un hospital del modelo probit
jpeg("task 3/view/logit_dist_hospi.jpeg")
modelplot(logit_marg,coef_map = ("dist_hospi")) + coord_flip()
dev.off()

# Exportar el grafico efecto marginal promedio de la distancia hasta un hospital del modelo logit
jpeg("task 3/view/probit_dist_hospi.jpeg")
modelplot(probit_marg,coef_map = ("dist_hospi")) + coord_flip()
dev.off()

# 3. Web-scraping (Class-14)
# 3.1 Objeto que contenga el HTML
myurl = "https://es.wikipedia.org/wiki/Departamentos_de_Colombia"

# Objeto que contenga el HTML de la p¬gina
myhtml = read_html(myurl)

# El tipo de objeto que es la variable myhtml
class(myhtml)

# 3.2 Extraer el t¬tulo de la p¬gina
# Direccion Xpath para obtener el nombre del articulo y convertirlo a texto
texto = myhtml %>% html_nodes(xpath = '//*[@id="firstHeading"]/text()') %>% html_text() # Convertir en texto
texto

# 3.3 Extraccion de la tabla que contiene los departamentos de Colombia
# Obtener todas las tablas del articulo
tabla = myhtml %>% html_nodes('table') 

# La tabla que tiene los departamentos es la 4.
# Se importa y convierte la tabla en un data frame.
departamentos = tabla[4] %>% html_table(header = T,fill=T)  %>% as.data.frame()

#Mostrar la tabla importada
View(departamentos)